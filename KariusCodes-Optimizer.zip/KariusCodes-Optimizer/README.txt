===========================================================================
  🌌 KARIUSOPTIMIZER v2.1 -- WINDOWS PERFORMANCE SUITE
===========================================================================
  Author      : Karius
  Target OS   : Windows 10 & Windows 11 (x64)
  Type        : Open-Source Performance & Low-Latency Suite
  Session Log : Automatically saved to your Desktop after run
===========================================================================

THANK YOU FOR DOWNLOADING!
This suite is designed to optimize system responsiveness, trim background 
telemetry bloat, unlock hidden performance plans, and minimize input lag/jitter.

---------------------------------------------------------------------------
🚀 HOW TO INSTALL & RUN (STEPS)
---------------------------------------------------------------------------
1. Extract (unzip) all contents of this zip file to a folder.
2. Right-click on "KariusOptimizer.bat".
3. Select "Run as administrator" (CRITICAL: Requires admin privileges).
4. Follow the interactive screen menu and choose your tweaks [1-8].
5. Check your Desktop for "KariusOptimizer_Log.txt" to see everything done.

---------------------------------------------------------------------------
🛡️ TRUST, FALSE POSITIVES & VIRUSTOTAL REPORT
---------------------------------------------------------------------------
Because this advanced batch script modifies system registry values (like Nagle's 
algorithm and input queue buffers) to achieve raw 1:1 performance, a few 
minor heuristic engines might flag it as generic "riskware". 

Don't panic! The script is 100% open-source. You can right-click the .bat file, 
select "Edit", and inspect every single line of code yourself.

Check the official, transparent 100% clean VirusTotal report here:
👉 https://www.virustotal.com/gui/file/459b82dd8e17c6b8ad96b4df38d319239a33c74ac8b6aab434c4d215c84af775/detection

---------------------------------------------------------------------------
📊 SCAN SUMMARY:
- Clean: 63 / 65 Engines (Microsoft Defender, Kaspersky, Bitdefender are CLEAN)
- Flags: 2 minor false positives due to registry tuning commands.
---------------------------------------------------------------------------

Have fun / Good luck gaming! 
-- Karius
===========================================================================